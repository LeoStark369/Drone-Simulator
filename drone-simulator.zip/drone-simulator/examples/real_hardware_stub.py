"""
Example: wiring the planner / avoidance / landing stack to a REAL
vehicle instead of the built-in simulated Drone.

This file is a template, not a ready-to-fly script — filling in the
pymavlink calls correctly for your specific autopilot (ArduPilot/PX4),
frame, and safety procedures is your responsibility. It exists to show
that the algorithmic code in `drone_sim/` (planner, avoidance, landing
state machine) is hardware-agnostic: it only depends on the
`DroneInterface` contract defined in `drone_sim/drone.py`.

Requires: pip install pymavlink
"""

from __future__ import annotations

from drone_sim.drone import DroneInterface, DroneState
from drone_sim.environment import Vector3


class MavlinkDrone(DroneInterface):
    """Skeleton DroneInterface implementation backed by a real MAVLink
    connection (e.g. Pixhawk/ArduPilot over telemetry radio or USB).

    Replace the TODO sections with real pymavlink calls. Keep the
    hard safety checks (geofence, battery failsafe, RC override) in
    your autopilot firmware — this class should never be the only
    layer standing between the algorithm and the airframe.
    """

    def __init__(self, connection_string: str = "udp:127.0.0.1:14550"):
        from pymavlink import mavutil  # imported lazily; optional dependency

        self.master = mavutil.mavlink_connection(connection_string)
        self.master.wait_heartbeat()
        self._state = DroneState()

    def get_state(self) -> DroneState:
        # TODO: read LOCAL_POSITION_NED / GLOBAL_POSITION_INT and
        # ATTITUDE messages via self.master.recv_match(...) and convert
        # to the local Vector3 / heading convention used by this
        # library (meters, radians, world frame).
        return self._state

    def set_velocity_command(self, velocity: Vector3) -> None:
        # TODO: send SET_POSITION_TARGET_LOCAL_NED with the velocity
        # bitmask set (type_mask enabling only vx/vy/vz), e.g.:
        #
        # self.master.mav.set_position_target_local_ned_send(
        #     0, self.master.target_system, self.master.target_component,
        #     mavutil.mavlink.MAV_FRAME_LOCAL_NED,
        #     0b0000111111000111,  # use velocity only
        #     0, 0, 0,
        #     velocity[0], velocity[1], -velocity[2],  # NED: down is +z
        #     0, 0, 0, 0, 0,
        # )
        raise NotImplementedError

    def step(self, dt: float) -> None:
        # For real hardware this is typically a no-op or a short sleep
        # -- the vehicle moves on its own; this call just paces the
        # control loop to `dt`.
        import time
        time.sleep(dt)

    def land(self) -> None:
        # TODO: send MAV_CMD_NAV_LAND, or switch flight mode to LAND.
        raise NotImplementedError


def main():
    """Sketch of how you'd reuse the exact same Simulator with a real
    vehicle. NOT runnable as-is -- see the TODOs above."""
    from drone_sim import Environment, Simulator
    from drone_sim.config import DEFAULT_CONFIG

    # In the real world your "Environment" would be built from live
    # sensor detections (e.g. clustering LIDAR/depth-camera point
    # clouds into Obstacle spheres/boxes) rather than a random scene.
    env = Environment(bounds=DEFAULT_CONFIG.world_bounds)

    drone = MavlinkDrone(connection_string="udp:127.0.0.1:14550")
    sim = Simulator(env, drone=drone, config=DEFAULT_CONFIG)

    result = sim.run_mission(start=(0, 0, 10), goal=(50, 50, 0), max_ticks=10_000)
    print(result)


if __name__ == "__main__":
    main()
