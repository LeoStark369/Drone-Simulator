"""
World representation: obstacles and collision/occupancy queries.

The Environment is intentionally geometry-based (spheres + axis-aligned
boxes) rather than a fixed voxel map, so it can represent real sensor
detections (point clouds fitted to primitives) as easily as synthetic
test scenes.
"""

from __future__ import annotations

import math
import random
from dataclasses import dataclass, field
from typing import List, Tuple

Vector3 = Tuple[float, float, float]


@dataclass
class Obstacle:
    """A static obstacle approximated as a sphere or an axis-aligned box.

    shape: "sphere" | "box"
    center: (x, y, z)
    For a sphere: `radius` is used.
    For a box: `half_extents` (hx, hy, hz) is used.
    """

    center: Vector3
    shape: str = "sphere"
    radius: float = 2.0
    half_extents: Vector3 = (1.0, 1.0, 1.0)

    def distance_to_point(self, point: Vector3) -> float:
        """Shortest distance from the obstacle surface to `point` (>=0 if outside)."""
        px, py, pz = point
        cx, cy, cz = self.center

        if self.shape == "sphere":
            d = math.dist(point, self.center)
            return max(0.0, d - self.radius)

        # Axis-aligned box: distance from point to box surface.
        hx, hy, hz = self.half_extents
        dx = max(abs(px - cx) - hx, 0.0)
        dy = max(abs(py - cy) - hy, 0.0)
        dz = max(abs(pz - cz) - hz, 0.0)
        return math.sqrt(dx * dx + dy * dy + dz * dz)

    def contains(self, point: Vector3) -> bool:
        return self.distance_to_point(point) <= 0.0

    def ray_intersect(self, origin: Vector3, direction: Vector3, max_dist: float):
        """Return distance along the ray to first intersection, or None.

        `direction` must be a unit vector. Sphere: analytic quadratic
        solve. Box: slab method. Both are standard closed-form ray
        intersection tests, adequate for a simulated LIDAR.
        """
        if self.shape == "sphere":
            return self._ray_sphere(origin, direction, max_dist)
        return self._ray_box(origin, direction, max_dist)

    def _ray_sphere(self, origin, direction, max_dist):
        ox, oy, oz = origin
        dx, dy, dz = direction
        cx, cy, cz = self.center
        lx, ly, lz = ox - cx, oy - cy, oz - cz

        a = dx * dx + dy * dy + dz * dz
        b = 2 * (lx * dx + ly * dy + lz * dz)
        c = lx * lx + ly * ly + lz * lz - self.radius * self.radius
        disc = b * b - 4 * a * c
        if disc < 0:
            return None
        sqrt_disc = math.sqrt(disc)
        t1 = (-b - sqrt_disc) / (2 * a)
        t2 = (-b + sqrt_disc) / (2 * a)
        t = t1 if t1 > 1e-6 else t2
        if t < 1e-6 or t > max_dist:
            return None
        return t

    def _ray_box(self, origin, direction, max_dist):
        ox, oy, oz = origin
        dx, dy, dz = direction
        cx, cy, cz = self.center
        hx, hy, hz = self.half_extents

        bmin = (cx - hx, cy - hy, cz - hz)
        bmax = (cx + hx, cy + hy, cz + hz)

        tmin, tmax = 1e-6, max_dist
        o = (ox, oy, oz)
        d = (dx, dy, dz)
        for i in range(3):
            if abs(d[i]) < 1e-9:
                if o[i] < bmin[i] or o[i] > bmax[i]:
                    return None
            else:
                t1 = (bmin[i] - o[i]) / d[i]
                t2 = (bmax[i] - o[i]) / d[i]
                if t1 > t2:
                    t1, t2 = t2, t1
                tmin = max(tmin, t1)
                tmax = min(tmax, t2)
                if tmin > tmax:
                    return None
        return tmin if tmin <= max_dist else None


@dataclass
class Environment:
    bounds: Tuple[Tuple[float, float], Tuple[float, float], Tuple[float, float]]
    obstacles: List[Obstacle] = field(default_factory=list)

    def add_obstacle(self, obstacle: Obstacle) -> None:
        self.obstacles.append(obstacle)

    def in_bounds(self, point: Vector3) -> bool:
        (xmin, xmax), (ymin, ymax), (zmin, zmax) = self.bounds
        x, y, z = point
        return xmin <= x <= xmax and ymin <= y <= ymax and zmin <= z <= zmax

    def is_free(self, point: Vector3, clearance: float = 0.0) -> bool:
        """True if `point` is inside bounds and at least `clearance` away
        from every obstacle surface."""
        if not self.in_bounds(point):
            return False
        return all(o.distance_to_point(point) >= clearance for o in self.obstacles)

    def nearest_obstacle_distance(self, point: Vector3) -> float:
        if not self.obstacles:
            return math.inf
        return min(o.distance_to_point(point) for o in self.obstacles)

    def cast_ray(self, origin: Vector3, direction: Vector3, max_range: float) -> float:
        """Return distance to the closest obstacle hit along the ray, or
        `max_range` if nothing is hit (this is what a real LIDAR/ToF
        sensor reports for an out-of-range reading)."""
        best = max_range
        for obs in self.obstacles:
            hit = obs.ray_intersect(origin, direction, best)
            if hit is not None and hit < best:
                best = hit
        return best

    @classmethod
    def random_scene(
        cls,
        bounds=((0.0, 100.0), (0.0, 100.0), (0.0, 50.0)),
        num_obstacles: int = 18,
        seed: int = None,
    ) -> "Environment":
        """Generate a reproducible random obstacle field, useful for demos
        and regression testing of the planner/avoidance stack."""
        rng = random.Random(seed)
        env = cls(bounds=bounds)
        (xmin, xmax), (ymin, ymax), (zmin, zmax) = bounds
        for _ in range(num_obstacles):
            shape = rng.choice(["sphere", "box"])
            center = (
                rng.uniform(xmin + 10, xmax - 10),
                rng.uniform(ymin + 10, ymax - 10),
                rng.uniform(zmin + 2, min(zmax, 25)),
            )
            if shape == "sphere":
                env.add_obstacle(Obstacle(center=center, shape="sphere",
                                           radius=rng.uniform(1.5, 4.0)))
            else:
                env.add_obstacle(Obstacle(
                    center=center, shape="box",
                    half_extents=(rng.uniform(1, 3), rng.uniform(1, 3), rng.uniform(1, 4)),
                ))
        return env
