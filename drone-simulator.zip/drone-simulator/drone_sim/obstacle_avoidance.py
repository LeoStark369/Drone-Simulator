"""
Reactive local obstacle avoidance using an artificial potential field
(APF), combining an attractive pull toward the next planned waypoint
with a repulsive push away from nearby obstacles detected by the
LIDAR sensor.

This runs every control tick on top of the global A* path, so the
drone reacts immediately to obstacles the global planner didn't know
about (dynamic obstacles, or a coarser planning grid than the real
world) without waiting for a full replan.
"""

from __future__ import annotations

import math
from typing import List

from .environment import Vector3
from .sensors import ScanPoint


def _normalize(v: Vector3) -> Vector3:
    n = math.sqrt(sum(c * c for c in v))
    if n < 1e-9:
        return (0.0, 0.0, 0.0)
    return tuple(c / n for c in v)  # type: ignore


def _sub(a: Vector3, b: Vector3) -> Vector3:
    return tuple(a[i] - b[i] for i in range(3))  # type: ignore


def _add(a: Vector3, b: Vector3) -> Vector3:
    return tuple(a[i] + b[i] for i in range(3))  # type: ignore


def _scale(a: Vector3, s: float) -> Vector3:
    return tuple(c * s for c in a)  # type: ignore


class PotentialFieldAvoider:
    def __init__(self, influence_radius: float = 8.0, repulsive_gain: float = 40.0,
                 attractive_gain: float = 1.0, min_safe_distance: float = 1.5):
        self.influence_radius = influence_radius
        self.repulsive_gain = repulsive_gain
        self.attractive_gain = attractive_gain
        self.min_safe_distance = min_safe_distance

    def compute_desired_velocity(
        self,
        position: Vector3,
        target: Vector3,
        scan_points: List[ScanPoint],
        max_speed: float,
    ) -> Vector3:
        """Blend attraction to `target` with repulsion from every LIDAR
        return closer than `influence_radius`. Returns a velocity vector
        (m/s) capped at `max_speed`."""

        # Attractive component: straight line toward the target.
        to_target = _sub(target, position)
        dist_to_target = math.sqrt(sum(c * c for c in to_target))
        attractive = _scale(_normalize(to_target), self.attractive_gain * min(dist_to_target, max_speed))

        # Repulsive component: sum contributions from each close-range hit.
        repulsive = (0.0, 0.0, 0.0)
        closest_obstacle_dist = math.inf

        for pt in scan_points:
            if pt.is_max_range or pt.range <= 1e-6:
                continue
            if pt.range > self.influence_radius:
                continue

            closest_obstacle_dist = min(closest_obstacle_dist, pt.range)
            away = _normalize(_sub(position, pt.hit_point))
            # Standard APF repulsive term: grows sharply as range -> 0.
            magnitude = self.repulsive_gain * (
                (1.0 / max(pt.range, 0.05)) - (1.0 / self.influence_radius)
            ) / (pt.range ** 2 + 1e-6)
            repulsive = _add(repulsive, _scale(away, magnitude))

        desired = _add(attractive, repulsive)

        # Hard safety override: if something is inside the minimum safe
        # distance, prioritize pure retreat over any blended heading.
        if closest_obstacle_dist < self.min_safe_distance:
            desired = _scale(_normalize(repulsive), max_speed)

        speed = math.sqrt(sum(c * c for c in desired))
        if speed > max_speed:
            desired = _scale(desired, max_speed / speed)

        return desired

    @staticmethod
    def is_path_blocked(scan_points: List[ScanPoint], heading: float,
                         cone_deg: float, block_range: float) -> bool:
        """Quick check used to trigger a global replan: is there an
        obstacle inside `block_range` within a forward cone of
        `cone_deg` around the current heading?"""
        half_cone = math.radians(cone_deg) / 2
        for pt in scan_points:
            if pt.is_max_range:
                continue
            angle_diff = (pt.angle - heading + math.pi) % (2 * math.pi) - math.pi
            if abs(angle_diff) <= half_cone and pt.range <= block_range:
                return True
        return False
