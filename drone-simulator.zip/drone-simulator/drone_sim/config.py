"""
Central configuration for the simulator.

Keeping tunables in one place makes it straightforward to retarget
this codebase at a real airframe: swap these values for your
vehicle's actual limits (max speed, sensor range, control gains)
without touching the algorithm code.
"""

from dataclasses import dataclass


@dataclass(frozen=True)
class SimConfig:
    # --- World ---
    world_bounds: tuple = ((0.0, 100.0), (0.0, 100.0), (0.0, 50.0))  # x, y, z (m)
    grid_resolution: float = 1.0  # meters per planning-grid cell

    # --- Drone dynamics / limits ---
    max_speed: float = 6.0        # m/s
    max_accel: float = 3.0        # m/s^2
    max_climb_rate: float = 2.0   # m/s
    control_dt: float = 0.1       # s, simulation / control loop timestep

    # --- LIDAR / sensor model ---
    lidar_num_rays: int = 36      # rays in the horizontal scan plane
    lidar_max_range: float = 15.0  # m
    lidar_vertical_layers: int = 3
    lidar_noise_std: float = 0.05  # m, gaussian range noise

    # --- Obstacle avoidance (artificial potential field) ---
    avoidance_influence_radius: float = 8.0
    avoidance_repulsive_gain: float = 40.0
    avoidance_attractive_gain: float = 1.0
    min_safe_distance: float = 1.5  # m, hard safety margin

    # --- Path planning ---
    replan_distance_threshold: float = 3.0  # replan if this far off planned path
    goal_tolerance: float = 1.0

    # --- Landing ---
    landing_descent_speed: float = 0.6       # m/s
    landing_final_altitude: float = 0.3      # m, switch to touchdown phase
    landing_hover_check_radius: float = 2.0  # m, clearance check under drone
    landing_max_tilt: float = 0.15           # rad, abort landing if exceeded


DEFAULT_CONFIG = SimConfig()
