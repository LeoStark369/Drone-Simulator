"""
Sensor models.

LidarSensor simulates a multi-layer rotating LIDAR (similar in spirit
to a Livox/RPLidar-class sensor used on real UAVs): it casts rays in a
horizontal fan across several vertical layers and returns range
readings, optionally with gaussian noise to mimic real hardware.

The output format (angle, layer, range, hit_point) is deliberately
close to what you'd get parsing a real point-cloud/scan message, so
`obstacle_avoidance.py` and `visualizer.py` work unchanged against
either simulated or real sensor data — just replace `scan()`'s
internals with your driver's `read()` call.
"""

from __future__ import annotations

import math
import random
from dataclasses import dataclass
from typing import List, Tuple

from .environment import Environment, Vector3


@dataclass
class ScanPoint:
    angle: float        # radians, in the drone's horizontal frame
    layer: float         # vertical angle offset, radians
    range: float          # meters
    hit_point: Vector3    # world-frame coordinates of the return
    is_max_range: bool    # True if this ray found nothing (no return)


class LidarSensor:
    def __init__(self, num_rays: int = 36, max_range: float = 15.0,
                 vertical_layers: int = 3, noise_std: float = 0.05,
                 vertical_fov_deg: float = 30.0, seed: int = None):
        self.num_rays = num_rays
        self.max_range = max_range
        self.vertical_layers = vertical_layers
        self.noise_std = noise_std
        self._rng = random.Random(seed)

        half_fov = math.radians(vertical_fov_deg) / 2
        if vertical_layers == 1:
            self._layer_angles = [0.0]
        else:
            self._layer_angles = [
                -half_fov + i * (2 * half_fov) / (vertical_layers - 1)
                for i in range(vertical_layers)
            ]

    def scan(self, position: Vector3, heading: float, env: Environment) -> List[ScanPoint]:
        """Perform a full 360-degree multi-layer scan from `position`.

        heading: drone yaw in radians (0 = +x axis), used so ray angles
        are expressed in the drone's body frame like a real sensor feed.
        """
        points: List[ScanPoint] = []
        px, py, pz = position

        for i in range(self.num_rays):
            body_angle = (2 * math.pi * i) / self.num_rays
            world_angle = body_angle + heading

            for layer_angle in self._layer_angles:
                dx = math.cos(world_angle) * math.cos(layer_angle)
                dy = math.sin(world_angle) * math.cos(layer_angle)
                dz = math.sin(layer_angle)
                direction = (dx, dy, dz)

                r = env.cast_ray(position, direction, self.max_range)
                is_max = r >= self.max_range - 1e-6

                if not is_max and self.noise_std > 0:
                    r = max(0.0, r + self._rng.gauss(0.0, self.noise_std))

                hit_point = (px + dx * r, py + dy * r, pz + dz * r)
                points.append(ScanPoint(
                    angle=body_angle, layer=layer_angle, range=r,
                    hit_point=hit_point, is_max_range=is_max,
                ))
        return points

    @staticmethod
    def min_range_by_sector(points: List[ScanPoint], num_sectors: int = 8) -> List[float]:
        """Bucket scan points into `num_sectors` horizontal sectors and
        return the minimum range in each — a compact summary an
        avoidance controller can act on cheaply."""
        sector_min = [math.inf] * num_sectors
        sector_size = 2 * math.pi / num_sectors
        for p in points:
            idx = int((p.angle % (2 * math.pi)) / sector_size) % num_sectors
            sector_min[idx] = min(sector_min[idx], p.range)
        return sector_min
