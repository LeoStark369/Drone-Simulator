"""
Autonomous landing sequence.

Implements a staged landing controller:

  1. APPROACH  - fly laterally to the landing site at cruise altitude.
  2. VERIFY    - hold position and check that the ground footprint
                 below the drone is clear of obstacles (using downward
                 LIDAR layer / clearance query).
  3. DESCEND   - controlled descent at a fixed vertical speed,
                 continuously re-checking clearance; abort back to
                 VERIFY/HOLD if something enters the footprint.
  4. TOUCHDOWN - final low-altitude slow-down and disarm.

This state-machine structure mirrors how real autopilots (e.g.
ArduPilot/PX4 precision-landing) stage a landing, so it is a reasonable
starting point for driving a real vehicle's landing logic, not just a
simulation nicety.
"""

from __future__ import annotations

import math
from enum import Enum, auto
from typing import Optional

from .drone import DroneInterface
from .environment import Environment, Vector3


class LandingPhase(Enum):
    APPROACH = auto()
    VERIFY = auto()
    DESCEND = auto()
    TOUCHDOWN = auto()
    COMPLETE = auto()
    ABORTED = auto()


class AutoLander:
    def __init__(self, landing_site: Vector3, descent_speed: float = 0.6,
                 final_altitude: float = 0.3, clearance_radius: float = 2.0,
                 approach_speed: float = 3.0):
        self.landing_site = landing_site
        self.descent_speed = descent_speed
        self.final_altitude = final_altitude
        self.clearance_radius = clearance_radius
        self.approach_speed = approach_speed

        self.phase = LandingPhase.APPROACH
        self._verify_hold_ticks = 0
        self._required_hold_ticks = 10  # ~1s at 0.1s control loop

    def is_site_clear(self, env: Environment, drone_position: Vector3) -> bool:
        """Check a vertical column above the pad for obstacles — stands
        in for a real downward-facing sensor / vision landing-marker
        check ("is anything in the way between here and the pad?")."""
        lx, ly, lz = self.landing_site
        px, py, _ = drone_position
        # Require lateral alignment before trusting the clearance check.
        if math.hypot(px - lx, py - ly) > self.clearance_radius:
            return False
        sample_heights = [lz + i * 0.5 for i in range(int((drone_position[2] - lz) / 0.5) + 1)]
        for h in sample_heights:
            if not env.is_free((lx, ly, h), clearance=self.clearance_radius * 0.5):
                return False
        return True

    def update(self, drone: DroneInterface, env: Environment, dt: float) -> LandingPhase:
        """Advance the landing state machine by one control tick and
        issue the appropriate velocity command to `drone`."""
        state = drone.get_state()
        px, py, pz = state.position
        lx, ly, lz = self.landing_site

        if self.phase == LandingPhase.APPROACH:
            dx, dy = lx - px, ly - py
            dist = math.hypot(dx, dy)
            if dist < 0.5:
                drone.set_velocity_command((0.0, 0.0, 0.0))
                self.phase = LandingPhase.VERIFY
                self._verify_hold_ticks = 0
            else:
                scale = min(self.approach_speed, dist) / max(dist, 1e-6)
                drone.set_velocity_command((dx * scale, dy * scale, 0.0))

        elif self.phase == LandingPhase.VERIFY:
            drone.set_velocity_command((0.0, 0.0, 0.0))
            if self.is_site_clear(env, state.position):
                self._verify_hold_ticks += 1
            else:
                self._verify_hold_ticks = 0
            if self._verify_hold_ticks >= self._required_hold_ticks:
                self.phase = LandingPhase.DESCEND

        elif self.phase == LandingPhase.DESCEND:
            if not self.is_site_clear(env, state.position):
                # Something moved into the landing footprint: hold and
                # re-verify rather than continuing to descend blind.
                drone.set_velocity_command((0.0, 0.0, 0.0))
                self.phase = LandingPhase.VERIFY
                self._verify_hold_ticks = 0
            elif pz - lz <= self.final_altitude:
                self.phase = LandingPhase.TOUCHDOWN
            else:
                drone.set_velocity_command((0.0, 0.0, -self.descent_speed))

        elif self.phase == LandingPhase.TOUCHDOWN:
            drone.set_velocity_command((0.0, 0.0, -self.descent_speed * 0.4))
            if pz - lz <= 0.05:
                drone.land()
                self.phase = LandingPhase.COMPLETE

        return self.phase
