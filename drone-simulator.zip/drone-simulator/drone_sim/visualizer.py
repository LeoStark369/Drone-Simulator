"""
Live 3D visualization of the simulation: obstacles, planned path,
flown trajectory, and current LIDAR returns.

Uses matplotlib's animation API so it works headless (save to file)
or interactively depending on the backend available.
"""

from __future__ import annotations

from typing import List, Optional

import matplotlib.pyplot as plt
import numpy as np
from mpl_toolkits.mplot3d.art3d import Poly3DCollection

from .environment import Environment, Obstacle
from .sensors import ScanPoint


class SimulatorVisualizer:
    def __init__(self, environment: Environment, figsize=(10, 8)):
        self.env = environment
        self.fig = plt.figure(figsize=figsize)
        self.ax = self.fig.add_subplot(111, projection="3d")
        self._dynamic_artists = []
        self._draw_static_scene()

    def _draw_static_scene(self):
        (xmin, xmax), (ymin, ymax), (zmin, zmax) = self.env.bounds
        self.ax.set_xlim(xmin, xmax)
        self.ax.set_ylim(ymin, ymax)
        self.ax.set_zlim(zmin, zmax)
        self.ax.set_xlabel("X (m)")
        self.ax.set_ylabel("Y (m)")
        self.ax.set_zlabel("Altitude (m)")
        self.ax.set_title("Autonomous Drone Simulator")

        for obs in self.env.obstacles:
            self._draw_obstacle(obs)

    def _draw_obstacle(self, obs: Obstacle):
        if obs.shape == "sphere":
            u = np.linspace(0, 2 * np.pi, 12)
            v = np.linspace(0, np.pi, 12)
            x = obs.center[0] + obs.radius * np.outer(np.cos(u), np.sin(v))
            y = obs.center[1] + obs.radius * np.outer(np.sin(u), np.sin(v))
            z = obs.center[2] + obs.radius * np.outer(np.ones_like(u), np.cos(v))
            self.ax.plot_surface(x, y, z, color="firebrick", alpha=0.35, linewidth=0)
        else:
            cx, cy, cz = obs.center
            hx, hy, hz = obs.half_extents
            self._draw_box(cx, cy, cz, hx, hy, hz)

    def _draw_box(self, cx, cy, cz, hx, hy, hz):
        corners = np.array([
            [cx - hx, cy - hy, cz - hz], [cx + hx, cy - hy, cz - hz],
            [cx + hx, cy + hy, cz - hz], [cx - hx, cy + hy, cz - hz],
            [cx - hx, cy - hy, cz + hz], [cx + hx, cy - hy, cz + hz],
            [cx + hx, cy + hy, cz + hz], [cx - hx, cy + hy, cz + hz],
        ])
        faces = [
            [corners[i] for i in (0, 1, 2, 3)],
            [corners[i] for i in (4, 5, 6, 7)],
            [corners[i] for i in (0, 1, 5, 4)],
            [corners[i] for i in (2, 3, 7, 6)],
            [corners[i] for i in (1, 2, 6, 5)],
            [corners[i] for i in (0, 3, 7, 4)],
        ]
        self.ax.add_collection3d(Poly3DCollection(
            faces, facecolor="saddlebrown", alpha=0.4, edgecolor="k", linewidths=0.3,
        ))

    def render_frame(self, trajectory: List, planned_path: Optional[List] = None,
                      scan_points: Optional[List[ScanPoint]] = None,
                      drone_position=None, save_path: Optional[str] = None):
        # Remove only the artists we added on the previous frame (path,
        # trajectory, scan points, drone marker) so the static obstacle
        # scene underneath is left untouched.
        for artist in self._dynamic_artists:
            artist.remove()
        self._dynamic_artists = []

        if planned_path:
            px = [p[0] for p in planned_path]
            py = [p[1] for p in planned_path]
            pz = [p[2] for p in planned_path]
            line, = self.ax.plot(px, py, pz, "b--", linewidth=1.5, label="Planned path")
            self._dynamic_artists.append(line)

        if trajectory:
            tx = [p[0] for p in trajectory]
            ty = [p[1] for p in trajectory]
            tz = [p[2] for p in trajectory]
            line, = self.ax.plot(tx, ty, tz, "g-", linewidth=2.0, label="Flown trajectory")
            self._dynamic_artists.append(line)

        if scan_points and drone_position:
            hx = [p.hit_point[0] for p in scan_points if not p.is_max_range]
            hy = [p.hit_point[1] for p in scan_points if not p.is_max_range]
            hz = [p.hit_point[2] for p in scan_points if not p.is_max_range]
            scatter = self.ax.scatter(hx, hy, hz, c="orange", s=8, alpha=0.6, label="LIDAR returns")
            self._dynamic_artists.append(scatter)

        if drone_position:
            marker = self.ax.scatter(*drone_position, c="blue", s=80, marker="^", label="Drone")
            self._dynamic_artists.append(marker)

        handles, labels = self.ax.get_legend_handles_labels()
        if handles:
            by_label = dict(zip(labels, handles))
            self.ax.legend(by_label.values(), by_label.keys(), loc="upper left")

        if save_path:
            self.fig.savefig(save_path, dpi=120)

        plt.pause(0.001)

    def save_gif(self, frame_dir: str, output_path: str, fps: int = 10):
        """Assemble previously saved frame PNGs into an animated GIF."""
        import glob
        import imageio.v2 as imageio

        files = sorted(glob.glob(f"{frame_dir}/*.png"))
        images = [imageio.imread(f) for f in files]
        imageio.mimsave(output_path, images, fps=fps)

    def show(self):
        plt.show()
