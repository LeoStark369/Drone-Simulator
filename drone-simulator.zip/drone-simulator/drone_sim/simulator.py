"""
Simulator: the main control loop that ties together the global
planner, reactive avoidance, sensor model, and autonomous landing
into one autonomous mission executor.

Mission flow each tick:
  1. Sense    - run the LIDAR scan from the current pose.
  2. Decide   - check whether the current heading is blocked; replan
                globally if so, otherwise get a local avoidance
                velocity that blends "go toward next waypoint" with
                "push away from nearby obstacles".
  3. Act      - command that velocity, step the vehicle.
  4. Land     - once within range of the goal, hand off to AutoLander.
"""

from __future__ import annotations

import logging
import math
from dataclasses import dataclass, field
from typing import List, Optional

from .config import SimConfig, DEFAULT_CONFIG
from .drone import Drone, DroneInterface
from .environment import Environment, Vector3
from .landing import AutoLander, LandingPhase
from .obstacle_avoidance import PotentialFieldAvoider
from .path_planner import AStarPlanner
from .sensors import LidarSensor, ScanPoint

logger = logging.getLogger("drone_sim.simulator")


@dataclass
class MissionResult:
    success: bool
    reason: str
    trajectory: List[Vector3] = field(default_factory=list)
    ticks: int = 0


class Simulator:
    def __init__(self, environment: Environment, drone: Optional[DroneInterface] = None,
                 config: SimConfig = DEFAULT_CONFIG, seed: int = None):
        self.env = environment
        self.config = config
        self.drone = drone
        self.sensor = LidarSensor(
            num_rays=config.lidar_num_rays, max_range=config.lidar_max_range,
            vertical_layers=config.lidar_vertical_layers, noise_std=config.lidar_noise_std,
            seed=seed,
        )
        self.planner = AStarPlanner(environment, resolution=config.grid_resolution)
        self.avoider = PotentialFieldAvoider(
            influence_radius=config.avoidance_influence_radius,
            repulsive_gain=config.avoidance_repulsive_gain,
            attractive_gain=config.avoidance_attractive_gain,
            min_safe_distance=config.min_safe_distance,
        )

        self.planned_path: List[Vector3] = []
        self._waypoint_idx = 0
        self.last_scan: List[ScanPoint] = []
        self.lander: Optional[AutoLander] = None

    def plan_mission(self, start: Vector3, goal: Vector3) -> bool:
        if self.drone is None:
            self.drone = Drone(start, max_speed=self.config.max_speed,
                                max_accel=self.config.max_accel)
        path = self.planner.plan(start, goal)
        if path is None:
            logger.warning("No path found from %s to %s", start, goal)
            return False
        self.planned_path = path
        self._waypoint_idx = 1 if len(path) > 1 else 0
        self.lander = AutoLander(
            landing_site=goal,
            descent_speed=self.config.landing_descent_speed,
            final_altitude=self.config.landing_final_altitude,
            clearance_radius=self.config.landing_hover_check_radius,
        )
        logger.info("Planned path with %d waypoints", len(path))
        return True

    def _current_target(self) -> Vector3:
        if self._waypoint_idx >= len(self.planned_path):
            return self.planned_path[-1]
        return self.planned_path[self._waypoint_idx]

    def _advance_waypoint_if_reached(self, position: Vector3):
        target = self._current_target()
        if math.dist(position, target) <= self.config.goal_tolerance:
            if self._waypoint_idx < len(self.planned_path) - 1:
                self._waypoint_idx += 1

    def _maybe_replan(self, position: Vector3, goal: Vector3) -> bool:
        target = self._current_target()
        blocked = self.avoider.is_path_blocked(
            self.last_scan, self.drone.get_state().heading,
            cone_deg=60, block_range=self.config.min_safe_distance * 2.5,
        )
        off_path = math.dist(position, target) > self.config.replan_distance_threshold * 3
        if blocked or off_path:
            new_path = self.planner.plan(position, goal)
            if new_path:
                self.planned_path = new_path
                self._waypoint_idx = 1 if len(new_path) > 1 else 0
                logger.info("Replanned path (%s) with %d waypoints",
                            "blocked" if blocked else "off-path", len(new_path))
                return True
        return False

    def run_tick(self, goal: Vector3) -> str:
        """Execute a single control-loop tick. Returns a status string:
        'flying', 'landing', 'complete', or 'aborted'."""
        state = self.drone.get_state()
        position = state.position

        self.last_scan = self.sensor.scan(position, state.heading, self.env)

        in_landing_phase = math.dist((position[0], position[1]), (goal[0], goal[1])) < \
            self.config.landing_hover_check_radius * 2

        if in_landing_phase or (self.lander and self.lander.phase != LandingPhase.APPROACH):
            phase = self.lander.update(self.drone, self.env, self.config.control_dt)
            self.drone.step(self.config.control_dt)
            if phase == LandingPhase.COMPLETE:
                return "complete"
            return "landing"

        self._maybe_replan(position, goal)
        self._advance_waypoint_if_reached(position)
        target = self._current_target()

        desired_velocity = self.avoider.compute_desired_velocity(
            position, target, self.last_scan, max_speed=self.config.max_speed,
        )
        self.drone.set_velocity_command(desired_velocity)
        self.drone.step(self.config.control_dt)
        return "flying"

    def run_mission(self, start: Vector3, goal: Vector3, max_ticks: int = 5000,
                     on_tick=None) -> MissionResult:
        """Run the full mission open-loop (no visualization) until
        landing completes or `max_ticks` is exceeded. `on_tick(sim, status)`
        is called after every tick if provided (e.g. to render a frame)."""
        if not self.plan_mission(start, goal):
            return MissionResult(success=False, reason="planning_failed")

        for tick in range(max_ticks):
            status = self.run_tick(goal)
            if on_tick:
                on_tick(self, status)
            if status == "complete":
                return MissionResult(
                    success=True, reason="landed",
                    trajectory=self.drone.trajectory, ticks=tick + 1,
                )
        return MissionResult(
            success=False, reason="max_ticks_exceeded",
            trajectory=self.drone.trajectory, ticks=max_ticks,
        )
