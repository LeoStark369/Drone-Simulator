"""
Drone state and dynamics.

`Drone` implements a simple but physically-reasonable point-mass model
(bounded acceleration/speed, first-order yaw-follows-velocity) that is
good enough to validate planning and avoidance logic in simulation.

`DroneInterface` is the abstraction point for real hardware: implement
it against pymavlink/DroneKit (or your flight controller's SDK) and
everything in `simulator.py` works unchanged, because it only talks to
this interface, not to the concrete `Drone` class.
"""

from __future__ import annotations

import math
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Tuple

from .environment import Vector3


@dataclass
class DroneState:
    position: Vector3 = (0.0, 0.0, 0.0)
    velocity: Vector3 = (0.0, 0.0, 0.0)
    heading: float = 0.0          # yaw, radians
    battery_pct: float = 100.0
    armed: bool = True
    landed: bool = False


class DroneInterface(ABC):
    """Hardware abstraction layer. Implement this against a real flight
    controller (e.g. via pymavlink) to run the same planner/avoidance/
    landing stack outside simulation."""

    @abstractmethod
    def get_state(self) -> DroneState: ...

    @abstractmethod
    def set_velocity_command(self, velocity: Vector3) -> None: ...

    @abstractmethod
    def step(self, dt: float) -> None:
        """Advance the vehicle (or, for real hardware, simply sleep /
        poll telemetry) by `dt` seconds."""
        ...

    @abstractmethod
    def land(self) -> None: ...


class Drone(DroneInterface):
    """Simulated point-mass drone with bounded acceleration and speed."""

    def __init__(self, start_position: Vector3, max_speed: float = 6.0,
                 max_accel: float = 3.0, battery_capacity_wh: float = 90.0,
                 power_draw_w: float = 180.0):
        self.state = DroneState(position=start_position)
        self.max_speed = max_speed
        self.max_accel = max_accel
        self._commanded_velocity: Vector3 = (0.0, 0.0, 0.0)

        self.battery_capacity_wh = battery_capacity_wh
        self.power_draw_w = power_draw_w
        self._energy_used_wh = 0.0

        self.trajectory: list = [start_position]

    def get_state(self) -> DroneState:
        return self.state

    def set_velocity_command(self, velocity: Vector3) -> None:
        speed = math.sqrt(sum(c * c for c in velocity))
        if speed > self.max_speed:
            scale = self.max_speed / speed
            velocity = tuple(c * scale for c in velocity)  # type: ignore
        self._commanded_velocity = velocity

    def step(self, dt: float) -> None:
        if self.state.landed or not self.state.armed:
            return

        vx, vy, vz = self.state.velocity
        cx, cy, cz = self._commanded_velocity

        # Bounded acceleration toward the commanded velocity (simple
        # first-order actuator response, avoids unrealistic instant
        # velocity changes).
        max_dv = self.max_accel * dt
        new_v = []
        for cur, cmd in zip((vx, vy, vz), (cx, cy, cz)):
            delta = cmd - cur
            delta = max(-max_dv, min(max_dv, delta))
            new_v.append(cur + delta)
        self.state.velocity = tuple(new_v)  # type: ignore

        px, py, pz = self.state.position
        vx, vy, vz = self.state.velocity
        new_position = (px + vx * dt, py + vy * dt, pz + vz * dt)
        self.state.position = new_position
        self.trajectory.append(new_position)

        horizontal_speed = math.hypot(vx, vy)
        if horizontal_speed > 0.05:
            self.state.heading = math.atan2(vy, vx)

        # Simple linear battery drain model.
        self._energy_used_wh += self.power_draw_w * (dt / 3600.0)
        self.state.battery_pct = max(
            0.0, 100.0 * (1 - self._energy_used_wh / self.battery_capacity_wh)
        )

    def land(self) -> None:
        self.state.velocity = (0.0, 0.0, 0.0)
        self.state.landed = True
        self.state.armed = False
