"""
Autonomous Drone Simulator
==========================

A modular Python framework for simulating autonomous drone flight:
obstacle avoidance, 3D path planning, autonomous landing, and live
sensor visualization.

Author: Surafel Gashaw (Leo Stark)
License: MIT
"""

__version__ = "1.0.0"
__author__ = "Surafel Gashaw (Leo Stark)"

from .environment import Environment, Obstacle
from .drone import Drone, DroneState
from .sensors import LidarSensor
from .path_planner import AStarPlanner
from .obstacle_avoidance import PotentialFieldAvoider
from .landing import AutoLander
from .simulator import Simulator

__all__ = [
    "Environment",
    "Obstacle",
    "Drone",
    "DroneState",
    "LidarSensor",
    "AStarPlanner",
    "PotentialFieldAvoider",
    "AutoLander",
    "Simulator",
]
