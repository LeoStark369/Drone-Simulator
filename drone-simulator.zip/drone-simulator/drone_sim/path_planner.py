"""
Global path planning via 3D A* search over a voxelized occupancy grid
built from the Environment's obstacles.

A* is used (rather than e.g. RRT) because it gives a deterministic,
reproducible, shortest-path-on-the-grid result, which matters for
testing and for predictable behavior in a real flight-safety context.
For very large / high-resolution worlds you would swap this module for
a sampling-based planner (RRT*) without changing its interface:
`plan(start, goal) -> List[Vector3]`.
"""

from __future__ import annotations

import heapq
import math
from typing import Dict, List, Optional, Tuple

from .environment import Environment, Vector3

GridCoord = Tuple[int, int, int]

# 26-connected neighborhood (all adjacent cells in 3D, including diagonals)
_NEIGHBOR_OFFSETS = [
    (dx, dy, dz)
    for dx in (-1, 0, 1)
    for dy in (-1, 0, 1)
    for dz in (-1, 0, 1)
    if not (dx == 0 and dy == 0 and dz == 0)
]


class AStarPlanner:
    def __init__(self, environment: Environment, resolution: float = 1.0,
                 safety_margin: float = 1.2):
        self.env = environment
        self.resolution = resolution
        self.safety_margin = safety_margin

    def _world_to_grid(self, point: Vector3) -> GridCoord:
        return tuple(int(round(c / self.resolution)) for c in point)  # type: ignore

    def _grid_to_world(self, coord: GridCoord) -> Vector3:
        return tuple(c * self.resolution for c in coord)  # type: ignore

    def _is_free(self, coord: GridCoord) -> bool:
        world_point = self._grid_to_world(coord)
        return self.env.is_free(world_point, clearance=self.safety_margin)

    @staticmethod
    def _heuristic(a: GridCoord, b: GridCoord) -> float:
        return math.dist(a, b)

    def plan(self, start: Vector3, goal: Vector3,
             max_iterations: int = 200_000) -> Optional[List[Vector3]]:
        """Run A* from `start` to `goal`. Returns a waypoint list in world
        coordinates, or None if no path was found within the iteration
        budget (e.g. goal is unreachable / enclosed by obstacles)."""
        start_c = self._world_to_grid(start)
        goal_c = self._world_to_grid(goal)

        open_heap: List[Tuple[float, GridCoord]] = [(0.0, start_c)]
        came_from: Dict[GridCoord, GridCoord] = {}
        g_score: Dict[GridCoord, float] = {start_c: 0.0}
        closed = set()

        iterations = 0
        while open_heap and iterations < max_iterations:
            iterations += 1
            _, current = heapq.heappop(open_heap)

            if current in closed:
                continue
            closed.add(current)

            if self._heuristic(current, goal_c) <= 1.5:
                return self._reconstruct_path(came_from, current, start, goal)

            for offset in _NEIGHBOR_OFFSETS:
                neighbor = (current[0] + offset[0], current[1] + offset[1], current[2] + offset[2])
                if neighbor in closed:
                    continue
                if not self._is_free(neighbor):
                    continue

                step_cost = math.sqrt(sum(o * o for o in offset))
                tentative_g = g_score[current] + step_cost

                if tentative_g < g_score.get(neighbor, math.inf):
                    came_from[neighbor] = current
                    g_score[neighbor] = tentative_g
                    f = tentative_g + self._heuristic(neighbor, goal_c)
                    heapq.heappush(open_heap, (f, neighbor))

        return None  # no path found within budget

    def _reconstruct_path(self, came_from, current, start, goal) -> List[Vector3]:
        path_coords = [current]
        while current in came_from:
            current = came_from[current]
            path_coords.append(current)
        path_coords.reverse()

        waypoints = [self._grid_to_world(c) for c in path_coords]
        waypoints[0] = start
        waypoints.append(goal)
        return self.smooth_path(waypoints)

    def smooth_path(self, waypoints: List[Vector3]) -> List[Vector3]:
        """Greedy line-of-sight smoothing: drop intermediate waypoints
        whenever a straight segment between two non-adjacent waypoints
        remains collision-free. Produces far fewer, more natural
        waypoints than the raw grid path."""
        if len(waypoints) <= 2:
            return waypoints

        smoothed = [waypoints[0]]
        i = 0
        while i < len(waypoints) - 1:
            j = len(waypoints) - 1
            while j > i + 1 and not self._segment_clear(waypoints[i], waypoints[j]):
                j -= 1
            smoothed.append(waypoints[j])
            i = j
        return smoothed

    def _segment_clear(self, a: Vector3, b: Vector3, samples: int = 20) -> bool:
        for k in range(samples + 1):
            t = k / samples
            point = tuple(a[d] + (b[d] - a[d]) * t for d in range(3))
            if not self.env.is_free(point, clearance=self.safety_margin):
                return False
        return True
