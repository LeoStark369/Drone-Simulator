from setuptools import find_packages, setup

setup(
    name="drone-sim",
    version="1.0.0",
    description="Autonomous Drone Simulator: obstacle avoidance, path planning, autonomous landing, sensor visualization",
    author="Surafel Gashaw (Leo Stark)",
    packages=find_packages(exclude=("tests",)),
    install_requires=[
        "numpy>=1.24",
        "matplotlib>=3.7",
        "imageio>=2.31",
    ],
    python_requires=">=3.9",
)
