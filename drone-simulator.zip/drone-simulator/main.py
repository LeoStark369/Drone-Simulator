#!/usr/bin/env python3
"""
Command-line entry point for the Autonomous Drone Simulator.

Examples
--------
Run a headless mission and print a summary:
    python main.py --seed 42

Run with live 3D visualization:
    python main.py --seed 42 --visualize

Run with visualization and save the final figure to a file:
    python main.py --seed 7 --visualize --save-fig out.png
"""

from __future__ import annotations

import argparse
import logging

from drone_sim import Environment, Simulator
from drone_sim.config import DEFAULT_CONFIG


def build_argparser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Autonomous Drone Simulator")
    p.add_argument("--seed", type=int, default=None, help="Random seed for the obstacle field")
    p.add_argument("--num-obstacles", type=int, default=18)
    p.add_argument("--start", type=float, nargs=3, default=[5.0, 5.0, 8.0], metavar=("X", "Y", "Z"))
    p.add_argument("--goal", type=float, nargs=3, default=[90.0, 90.0, 0.0], metavar=("X", "Y", "Z"))
    p.add_argument("--max-ticks", type=int, default=4000)
    p.add_argument("--visualize", action="store_true", help="Render a live matplotlib window")
    p.add_argument("--save-fig", type=str, default=None, help="Path to save the final frame as PNG")
    p.add_argument("--log-level", type=str, default="INFO")
    return p


def main():
    args = build_argparser().parse_args()
    logging.basicConfig(level=args.log_level, format="%(levelname)s %(name)s: %(message)s")

    env = Environment.random_scene(
        bounds=DEFAULT_CONFIG.world_bounds,
        num_obstacles=args.num_obstacles,
        seed=args.seed,
    )
    sim = Simulator(env, seed=args.seed)

    start = tuple(args.start)
    goal = tuple(args.goal)

    visualizer = None
    if args.visualize:
        from drone_sim.visualizer import SimulatorVisualizer
        visualizer = SimulatorVisualizer(env)

    def on_tick(sim: Simulator, status: str):
        if visualizer:
            visualizer.render_frame(
                trajectory=sim.drone.trajectory,
                planned_path=sim.planned_path,
                scan_points=sim.last_scan,
                drone_position=sim.drone.get_state().position,
            )

    result = sim.run_mission(start, goal, max_ticks=args.max_ticks, on_tick=on_tick)

    print("=" * 50)
    print(f"Mission success : {result.success}")
    print(f"Reason          : {result.reason}")
    print(f"Ticks executed  : {result.ticks}")
    print(f"Trajectory pts  : {len(result.trajectory)}")
    print("=" * 50)

    if visualizer:
        if args.save_fig:
            visualizer.fig.savefig(args.save_fig, dpi=150)
            print(f"Saved final frame to {args.save_fig}")
        visualizer.show()


if __name__ == "__main__":
    main()
