import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from drone_sim import Environment, Simulator
from drone_sim.config import SimConfig


def test_mission_lands_successfully_in_open_field():
    env = Environment(bounds=((0, 40), (0, 40), (0, 20)))
    config = SimConfig(control_dt=0.1)
    sim = Simulator(env, config=config, seed=1)

    result = sim.run_mission(start=(2, 2, 6), goal=(35, 35, 0), max_ticks=3000)

    assert result.success is True
    assert result.reason == "landed"
    final_position = result.trajectory[-1]
    assert abs(final_position[2]) < 0.5


def test_mission_avoids_obstacles_between_start_and_goal():
    env = Environment.random_scene(bounds=((0, 60), (0, 60), (0, 20)), num_obstacles=10, seed=3)
    sim = Simulator(env, seed=3)

    result = sim.run_mission(start=(2, 2, 6), goal=(55, 55, 0), max_ticks=4000)

    # Every point actually flown must respect a minimum clearance from
    # every obstacle -- this is the core safety property under test.
    for point in result.trajectory:
        assert env.nearest_obstacle_distance(point) >= -0.2  # small tolerance for step discretization
