import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from drone_sim.environment import Environment, Obstacle
from drone_sim.sensors import LidarSensor


def test_scan_detects_nearby_sphere():
    env = Environment(bounds=((0, 50), (0, 50), (0, 20)))
    env.add_obstacle(Obstacle(center=(10, 0, 0), shape="sphere", radius=2))
    sensor = LidarSensor(num_rays=72, max_range=20, vertical_layers=1, noise_std=0.0)
    points = sensor.scan(position=(0, 0, 0), heading=0.0, env=env)

    hits = [p for p in points if not p.is_max_range]
    assert len(hits) > 0
    closest = min(p.range for p in hits)
    # Sphere surface is at distance 10 - 2 = 8 from the sensor origin.
    assert abs(closest - 8.0) < 0.5


def test_scan_reports_max_range_in_open_space():
    env = Environment(bounds=((0, 50), (0, 50), (0, 20)))
    sensor = LidarSensor(num_rays=36, max_range=15, vertical_layers=1, noise_std=0.0)
    points = sensor.scan(position=(25, 25, 5), heading=0.0, env=env)
    assert all(p.is_max_range for p in points)
    assert all(abs(p.range - 15.0) < 1e-6 for p in points)


def test_min_range_by_sector_shape():
    env = Environment(bounds=((0, 50), (0, 50), (0, 20)))
    sensor = LidarSensor(num_rays=36, max_range=15, vertical_layers=1, noise_std=0.0)
    points = sensor.scan(position=(25, 25, 5), heading=0.0, env=env)
    sectors = LidarSensor.min_range_by_sector(points, num_sectors=8)
    assert len(sectors) == 8
