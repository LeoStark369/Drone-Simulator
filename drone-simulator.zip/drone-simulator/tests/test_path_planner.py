import math
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from drone_sim.environment import Environment, Obstacle
from drone_sim.path_planner import AStarPlanner


def test_plan_open_field_is_direct():
    env = Environment(bounds=((0, 20), (0, 20), (0, 20)))
    planner = AStarPlanner(env, resolution=1.0, safety_margin=0.5)
    path = planner.plan((1, 1, 5), (18, 18, 5))
    assert path is not None
    assert math.dist(path[0], (1, 1, 5)) < 1e-6
    assert math.dist(path[-1], (18, 18, 5)) < 1e-6
    # A direct-ish route in open space should need very few waypoints
    # after smoothing.
    assert len(path) <= 4


def test_plan_routes_around_single_obstacle():
    env = Environment(bounds=((0, 20), (0, 20), (0, 20)))
    env.add_obstacle(Obstacle(center=(10, 10, 5), shape="sphere", radius=4))
    planner = AStarPlanner(env, resolution=1.0, safety_margin=0.5)
    path = planner.plan((1, 10, 5), (19, 10, 5))
    assert path is not None
    for point in path:
        assert env.nearest_obstacle_distance(point) >= 0.0


def test_plan_returns_none_when_goal_enclosed():
    env = Environment(bounds=((0, 20), (0, 20), (0, 20)))
    # Enclose the goal in a box obstacle much larger than it, so no
    # free cell exists near the goal at this safety margin.
    env.add_obstacle(Obstacle(center=(18, 18, 5), shape="box", half_extents=(3, 3, 3)))
    planner = AStarPlanner(env, resolution=1.0, safety_margin=1.0)
    path = planner.plan((1, 1, 5), (18, 18, 5))
    assert path is None


def test_smoothed_path_has_fewer_or_equal_points():
    env = Environment(bounds=((0, 30), (0, 30), (0, 30)))
    planner = AStarPlanner(env, resolution=1.0, safety_margin=0.5)
    raw = [(0, 0, 5), (1, 0, 5), (2, 0, 5), (3, 0, 5), (4, 0, 5)]
    smoothed = planner.smooth_path(raw)
    assert len(smoothed) <= len(raw)
    assert smoothed[0] == raw[0]
    assert smoothed[-1] == raw[-1]
